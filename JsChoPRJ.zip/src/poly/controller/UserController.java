package poly.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import poly.dto.UserDTO;
import poly.service.IUserService;

import poly.util.CmmUtil;
import poly.util.EncryptUtil;

@Controller
public class UserController {

	private Logger log = Logger.getLogger(this.getClass());

	@Resource(name = "UserService")
	private IUserService userservice;

	@RequestMapping(value = "/project/ProjectJoin")
	public String ProjectJoin() {
		log.info(this.getClass());

		return "/project/ProjectJoin";

	}

	@RequestMapping("/project/insertUserInfo")
	public String insertUserInfo(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {

		log.info(this.getClass().getName() + ".insertUserInfo start!");

		String msg = "";

		UserDTO pDTO = null;

		try {
			String user_Id = CmmUtil.nvl(request.getParameter("user_Id"));
			String user_Name = CmmUtil.nvl(request.getParameter("user_Name"));
			String user_Pw = CmmUtil.nvl(request.getParameter("user_Pw"));
			String user_Nick = CmmUtil.nvl(request.getParameter("user_Nick"));

			log.info("user_Id확인 : " + user_Id);
			log.info("user_Name확인 : " + user_Name);
			log.info("user_Pw확인 : " + user_Pw);
			log.info("user_Nick확인 : " + user_Nick);

			pDTO = new UserDTO();

			pDTO.setUser_Id(EncryptUtil.encAES128CBC(user_Id));

			pDTO.setUser_Pw(EncryptUtil.encHashSHA256(user_Pw));
			pDTO.setUser_Name(user_Name);
			pDTO.setUser_Nick(user_Nick);

			int res = userservice.insertUserInfo(pDTO);

			if (res == 1) {
				msg = "회원가입 되었습니다.";
			} else if (res == 2) {
				msg = "이미 가입된 아이디 입니다.";

			} else {
				msg = "오류로 인해 회원가입이 실패하였습니다.";
			}
		} catch (Exception e) {

			msg = "실패하였습니다. :" + e.toString();
			log.info(e.toString());
			e.printStackTrace();

		} finally {
			log.info(this.getClass().getName() + ".insertUserInfo end!");

			model.addAttribute("msg", msg);

			pDTO = null;
		}

		return "/project/Msg";
	}
	
	@RequestMapping(value = "/project/getUserLoginCheck")
	public String getUserLoginCheck(HttpSession session, HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {
		log.info(this.getClass().getName() + ".getUserLoginCheck start!");

		int res = 0;

		UserDTO pDTO = null;

		try {
			String user_Id = CmmUtil.nvl(request.getParameter("user_Id"));
			String user_Pw = CmmUtil.nvl(request.getParameter("user_Pw"));

			log.info("user_Id : " + user_Id);
			log.info("user_Pw : " + user_Pw);

			pDTO = new UserDTO();

			pDTO.setUser_Id(EncryptUtil.encAES128CBC(user_Id));

			pDTO.setUser_Pw(EncryptUtil.encHashSHA256(user_Pw));

			res = userservice.getUserLoginCheck(pDTO);

			if (res == 1) {
				pDTO = userservice.getUserInfo(pDTO);
				log.info("닉네임: " + pDTO.getUser_Nick());
				session.setAttribute("SS_USER_ID", pDTO.getUser_Id());
				session.setAttribute("SS_USER_NICK", pDTO.getUser_Nick());
				session.setAttribute("SS_USER_SEQ", pDTO.getUser_Seq());
				session.setAttribute("SS_USER_PW", pDTO.getUser_Pw());

				log.info("세션 켜짐");
				log.info(session.getAttribute("SS_USER_ID"));
				log.info(session.getAttribute("SS_USER_SEQ"));
				log.info(session.getAttribute("SS_USER_PW"));

				model.addAttribute("msg", "로그인 되었습니다.");
				model.addAttribute("url", "/project/ProjectMain.do");

				return "redirect";

			} else {
				model.addAttribute("msg", "아이디 혹은 비밀번호가 맞지 않습니다.");
				model.addAttribute("url", "/project/ProjectLogin.do");

				return "redirect";
			}
		} catch (Exception e) {

			res = 2;
			log.info(e.toString());
			e.printStackTrace();

		} finally {
			log.info(this.getClass().getName() + ".insertUserInfo end!");

			model.addAttribute("res", String.valueOf(res));

			pDTO = null;

		}
		return "/project/LoginResult";
	}

	@RequestMapping(value = "/project/logOutTry")
	public String logOutTry(HttpSession session, HttpServletRequest request, Model model) throws Exception {
		request.getSession().removeAttribute("SS_USER_ID");
		request.getSession().removeAttribute("SS_USER_NICK");
		request.getSession().removeAttribute("SS_USER_SEQ");
		request.getSession().removeAttribute("SS_USER_PW");
		log.info("세션 꺼짐");
		model.addAttribute("msg", "로그아웃 되었습니다.");
		model.addAttribute("url", "/project/ProjectMain.do");

		return "redirect";
	}

	@RequestMapping(value = "/project/PwFind")
	public String PwFind() throws Exception {

		return "/project/PwFind";
	}
	
	@RequestMapping(value = "/project/PwFind2")
	public String PwFind2() throws Exception {

		return "/project/PwFind2";
	}

	@RequestMapping(value = "/project/IdFind")
	public String IdFind() throws Exception {

		return "/project/IdFind";
	}

	// 비밀번호 변경
	@RequestMapping(value = "/project/PwFindTry")
	public String PwFindTry(HttpSession session, HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {
		int res = 0;

		UserDTO pDTO = null;

		try {

			String user_Id = CmmUtil.nvl(request.getParameter("user_Id"));
			String user_Nick = CmmUtil.nvl(request.getParameter("user_Nick"));
			
			
			log.info("user_Id : " + user_Id);
			log.info("user_Nick : " + user_Nick);
			

			pDTO = new UserDTO();

			pDTO.setUser_Id(EncryptUtil.encAES128CBC(user_Id));
			pDTO.setUser_Nick(user_Nick);

			res = userservice.getUserPwChange(pDTO);

			log.info("res : " + res);

			if (res == 1) {
				
				model.addAttribute("msg", "인증 되었습니다.");
				model.addAttribute("url", "/project/PwChange.do");				

			} else {
				model.addAttribute("msg", "아이디 혹은 별명이 맞지 않습니다.");
				model.addAttribute("url", "/project/PwFind.do");

			}

		} catch (Exception e) {

			res = 2;
			log.info(e.toString());
			e.printStackTrace();

		} finally {
			log.info(this.getClass().getName() + ".insertUserInfo end!");

			model.addAttribute("res", String.valueOf(res));

			pDTO = null;

		}
		return "redirect";
	}
	
	// 비밀번호 변경
		@RequestMapping(value = "/project/PwFindTry2")
		public String PwFindTry2(HttpSession session, HttpServletRequest request, HttpServletResponse response,
				ModelMap model) throws Exception {
			int res = 0;

			UserDTO pDTO = null;

			try {

				String user_Id = CmmUtil.nvl(request.getParameter("user_Id"));
				String user_Nick = CmmUtil.nvl(request.getParameter("user_Nick"));
				
				
				log.info("user_Id : " + user_Id);
				log.info("user_Nick : " + user_Nick);
				

				pDTO = new UserDTO();

				pDTO.setUser_Id(EncryptUtil.encAES128CBC(user_Id));
				pDTO.setUser_Nick(user_Nick);

				res = userservice.getUserPwChange(pDTO);

				log.info("res : " + res);

				if (res == 1) {
					
					session.setAttribute("SS_USER_NICK",user_Nick);
					model.addAttribute("msg", "인증 되었습니다.");
					model.addAttribute("url", "/project/PwChange2.do");				

				} else {
					model.addAttribute("msg", "아이디 혹은 별명이 맞지 않습니다.");
					model.addAttribute("url", "/project/PwFind2.do");

				}

			} catch (Exception e) {

				res = 2;
				log.info(e.toString());
				e.printStackTrace();

			} finally {
				log.info(this.getClass().getName() + ".insertUserInfo end!");

				model.addAttribute("res", String.valueOf(res));

				pDTO = null;

			}
			return "redirect";
		}

	// 아이디 변경
	@RequestMapping(value = "/project/IdFindTry")
	public String IdFindTry(HttpSession session, HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {
		int res = 0;

		UserDTO pDTO = null;

		try {
			
			String user_Name = CmmUtil.nvl(request.getParameter("user_Name"));
			String user_Nick = CmmUtil.nvl(request.getParameter("user_Nick"));
			
			

			log.info("user_Name : " + user_Name);
			log.info("user_Nick : " + user_Nick);

			pDTO = new UserDTO();

			pDTO.setUser_Name(user_Name);
			pDTO.setUser_Nick(user_Nick);

			res = userservice.getUserIdFind(pDTO);

			String user_Id = userservice.getUserId(pDTO);

			log.info("res : " + res);

			if (res == 1) {

				
				user_Id = EncryptUtil.decAES128CBC(user_Id);

				log.info("user_Id : " + user_Id);

				model.addAttribute("msg", "인증 되었습니다. 아이디는 " + user_Id + " 입니다.");
				model.addAttribute("url", "/project/ProjectLogin.do");

			} else {
				model.addAttribute("msg", "이름 혹은 별명이 맞지 않습니다.");
				model.addAttribute("url", "/project/IdFind.do");

			}

		} catch (Exception e) {

			res = 2;
			log.info(e.toString());
			e.printStackTrace();

		} finally {
			log.info(this.getClass().getName() + ".insertUserInfo end!");

			model.addAttribute("res", String.valueOf(res));

			pDTO = null;

		}
		return "redirect";
	}

	@RequestMapping(value = "/project/PwChange")
	public String PwChange() throws Exception {

		return "/project/PwChange";
	}
	@RequestMapping(value = "/project/PwChange2")
	public String PwChange2() throws Exception {

		return "/project/PwChange2";
	}

	@RequestMapping(value = "/project/PwChangeTry")
	public String PwChangeTry(HttpSession session, HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		UserDTO pDTO = null;

		try {
			
			String user_Pw = CmmUtil.nvl(request.getParameter("user_Pw"));
			String user_Nick = (String)session.getAttribute("SS_USER_NICK");
			
			log.info("user_Pw확인 : " + user_Pw);
			log.info("user_Nick : " + user_Nick);

			pDTO = new UserDTO();

			pDTO.setUser_Pw(EncryptUtil.encHashSHA256(user_Pw));
			pDTO.setUser_Nick(user_Nick);
			

			
			log.info(pDTO.getUser_Pw());

			int res = userservice.UpdatePw(pDTO);

			log.info("res : " + res);
			if (res == 1) {
				model.addAttribute("msg", "비밀번호가 변경 되었습니다.");
				model.addAttribute("url", "/project/ProjectMypage.do");
			} else {
				model.addAttribute("msg", "비밀번호변경 실패.");
				model.addAttribute("url", "/project/ProjectMypage.do");
			}

		} catch (Exception e) {

			log.info(e.toString());
			e.printStackTrace();

		}
		pDTO = null;

		return "redirect";
	}
	
	@RequestMapping(value = "/project/PwChangeTry2")
	public String PwChangeTry2(HttpSession session, HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		UserDTO pDTO = null;

		try {
			
			String user_Pw = CmmUtil.nvl(request.getParameter("user_Pw"));
			String user_Nick = (String)session.getAttribute("SS_USER_NICK");
			
			log.info("user_Pw확인 : " + user_Pw);
			log.info("user_Nick : " + user_Nick);

			pDTO = new UserDTO();

			pDTO.setUser_Pw(EncryptUtil.encHashSHA256(user_Pw));
			pDTO.setUser_Nick(user_Nick);
			

			
			log.info(pDTO.getUser_Pw());

			int res = userservice.UpdatePw(pDTO);

			log.info("res : " + res);
			if (res == 1) {
				model.addAttribute("msg", "비밀번호가 변경 되었습니다.");
				model.addAttribute("url", "/project/ProjectLogin.do");
				request.getSession().removeAttribute("SS_USER_NICK");
			} else {
				model.addAttribute("msg", "비밀번호변경 실패.");
				model.addAttribute("url", "/project/ProjectLogin.do");
				request.getSession().removeAttribute("SS_USER_NICK");
			}

		} catch (Exception e) {

			log.info(e.toString());
			e.printStackTrace();

		}
		pDTO = null;

		return "redirect";
	}

	@RequestMapping(value = "/project/MemberAdmin")
	public String MemberAdmin(HttpSession session, HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		if (session.getAttribute("SS_USER_ID") == null) {
			model.addAttribute("url", "/project/ProjectLogin.do");
			model.addAttribute("msg", "로그인 후 이용 가능합니다.");

			return "redirect";
		} else {
			List<UserDTO> rList = new ArrayList<>();

			log.info("--11--");
			log.info(rList);

			try {
				rList = userservice.getUserInfo3();
			} catch (Exception e) {
				e.printStackTrace();
			}
			model.addAttribute("rList", rList);

			log.info("--22--");
			log.info(rList);

			return "/project/MemberAdmin";
		}

	}

	@RequestMapping(value = "/project/MemberDelete")
	public String MemberDelete(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("User_Seq");

		UserDTO rDTO = new UserDTO();
		rDTO.setUser_Seq(seq);

		int result = 0;

		try {
			result = userservice.getUserDelete(rDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result > 0) {
			model.addAttribute("msg", "삭제되었습니다.");
			model.addAttribute("url", "/project/MemberAdmin.do");

		} else {
			model.addAttribute("msg", "삭제 실패했습니다.");
			model.addAttribute("url", "/project/MemberAdmin.do");
		}

		return "redirect";

	}

	@RequestMapping(value = "/idCheck", method = RequestMethod.GET)
	public @ResponseBody String idCheck(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userid = EncryptUtil.encAES128CBC(CmmUtil.nvl(request.getParameter("user_Id")));

		log.info("userid : " + userid);

		String count = "";

		try {
			count = userservice.idcheck(userid);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// String test ="ok";
		log.info("count : " + count);
		// return test;

		if (count.equals("0")) {
			return "0";
		} else {
			return "1";
		}
	}

	@RequestMapping(value = "/Nickcheck", method = RequestMethod.GET)
	public @ResponseBody String Nickcheck(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String user_Nick = CmmUtil.nvl(request.getParameter("user_Nick"));

		log.info("user_Nick : " + user_Nick);

		String count = "";

		try {
			count = userservice.NickCheck(user_Nick);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// String test ="ok";
		log.info("count : " + count);
		// return test;

		if (count.equals("0")) {
			return "0";
		} else {
			return "1";
		}
	}

	@RequestMapping(value = "/project/MemberDeleteCheck")
	public String MemberDeleteCheck(HttpSession session, HttpServletResponse response, HttpServletRequest request,
			Model model) {

		return "/project/MemberDeleteCheck";
	}

	@RequestMapping(value = "/project/MemberDeleteTry")
		public String MemberDeleteTry(HttpSession session,HttpServletResponse response,HttpServletRequest request, Model model) {
			log.info(this.getClass().getName());

			String user_Pw = request.getParameter("user_Pw");
			String user_Seq = (String) session.getAttribute("SS_USER_SEQ");
			log.info("user_Seq :" + user_Seq);
			
			
			
			try {
				user_Pw = EncryptUtil.encHashSHA256(user_Pw);
				
				log.info("user_Pw :" + user_Pw);
				log.info("session 비밀번호 :"+session.getAttribute("SS_USER_PW"));
				
				if(user_Pw.equals(session.getAttribute("SS_USER_PW"))) {
					
					
					UserDTO rDTO = new UserDTO();
					rDTO.setUser_Seq(user_Seq);

					int result = 0;

					result = userservice.getUserDelete(rDTO);
					
					log.info("result :" + result);
					
					if (result > 0) {
						model.addAttribute("msg", "회원탈퇴 되었습니다.");
						model.addAttribute("url", "ProjectMain.do");
						request.getSession().removeAttribute("SS_USER_ID");
						log.info("세션 꺼짐");

					}
				} 
				else {
						model.addAttribute("msg", "비밀번호가 다릅니다.");
						model.addAttribute("url", "/project/ProjectMypage.do");
						}
				}catch (Exception e) {
					e.printStackTrace();
			}
			
			return"redirect";

	}
}
