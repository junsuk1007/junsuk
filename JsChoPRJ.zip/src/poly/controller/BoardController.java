package poly.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import poly.dto.BoardDTO;
import poly.dto.UserDTO;
import poly.service.IBoardService;
import poly.service.IUserService;
import poly.util.CmmUtil;

@Controller
public class BoardController {

	private Logger log = Logger.getLogger(this.getClass()); // 로그 선언

	@Resource(name = "BoardService")
	private IBoardService BoardService;
	@Resource(name = "UserService")
	private IUserService userservice;


	//글작성
	@RequestMapping(value = "/project/boardReg")
	public String Regboard() {
		log.info(this.getClass().getName());

		return "project/boardReg";
	}
	
	//글등록
	@RequestMapping(value = "project/boardRegProc")
	public String BoardRegProc(HttpServletRequest request,HttpSession session, Model model) {
		log.info(this.getClass().getName());
		
		String user_Nick =  CmmUtil.nvl((String)session.getAttribute("SS_USER_NICK"));
		String title = request.getParameter("title");
		String contents = request.getParameter("contents");
		
		log.info("작성자 : "+user_Nick);
		log.info(title);
		log.info(contents);
		

		BoardDTO bDTO = new BoardDTO();
		bDTO.setUser_Nick(user_Nick);
		bDTO.setContent(contents);
		bDTO.setTitle(title);
		

		int result = 0;

		try {
			result = BoardService.insertBoardInfo(bDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (result > 0) {
			model.addAttribute("url", "/project/ProjectReview.do");
			model.addAttribute("msg", "등록되었습니다.");
		} else {
			model.addAttribute("url", "/project/ProjectReview.do");
			model.addAttribute("msg", "등록에 실패했습니다.");

		}

		return "/redirect";
	}

	//게시글 보기
	@RequestMapping(value = "/project/ProjectReview")
	public String ProjectReview(HttpSession session,HttpServletRequest request,  Model model) throws Exception {
		log.info(this.getClass().getName());

		if(session.getAttribute("SS_USER_ID")==null) {
			model.addAttribute("url", "/project/ProjectLogin.do");
			model.addAttribute("msg", "로그인 후 이용 가능합니다.");
			
			return "redirect";
		}else {
			log.info(this.getClass().getName() + "보드 받아오기 시작");
			
			int pgNum = 1;
			
			if(request.getParameter("pgNum")!=null) {
				pgNum = Integer.parseInt(request.getParameter("pgNum"));
			}
			
			int startNum = (pgNum-1)*10 +1;
			int endNum = (pgNum-1)*10 +10;
			List<BoardDTO> bList = new ArrayList<>();
			
			int seq = 1;
			
			if(request.getParameter("seq")!= null) {
				seq = Integer.parseInt(request.getParameter("seq"));
			}
			int total = Integer.parseInt(BoardService.getBoardCnt());
			
			bList = BoardService.getProjectReview(startNum, endNum);
			model.addAttribute("pgNum", pgNum);
			model.addAttribute("total", total);
			model.addAttribute("bList", bList);
			
			log.info(this.getClass().getName() + "보드 받아오기 끝");
						
		return "/project/ProjectReview";
		}
	}
	
	  //관리자 리뷰관리
	  
	  @RequestMapping(value = "/project/ReviewAdmin") public String
	  ReviewAdmin(HttpSession session,HttpServletRequest request, Model model) throws Exception {
	  log.info(this.getClass().getName());
	  
	  if(session.getAttribute("SS_USER_ID")==null) { model.addAttribute("url",
	  "/project/ProjectLogin.do"); model.addAttribute("msg", "로그인 후 이용 가능합니다.");
	  
	  return "redirect"; 
	  }	 else { 
		  log.info(this.getClass().getName() + "보드 받아오기 시작");
			
			int pgNum = 1;
			
			if(request.getParameter("pgNum")!=null) {
				pgNum = Integer.parseInt(request.getParameter("pgNum"));
			}
			
			int startNum = (pgNum-1)*10 +1;
			int endNum = (pgNum-1)*10 +10;
			List<BoardDTO> bList = new ArrayList<>();
			
			int seq = 1;
			
			if(request.getParameter("seq")!= null) {
				seq = Integer.parseInt(request.getParameter("seq"));
			}
			int total = Integer.parseInt(BoardService.getBoardCnt());
			
			bList = BoardService.getProjectReview(startNum, endNum);
			model.addAttribute("pgNum", pgNum);
			model.addAttribute("total", total);
			model.addAttribute("bList", bList);
			
			log.info(this.getClass().getName() + "보드 받아오기 끝");
	  
	  return "/project/ReviewAdmin";
	  	}
	  
	  }
	 
	
	//게시글 디테일
	@RequestMapping(value = "project/boardDetail")
	public String BoardDetail(HttpSession session,HttpServletRequest request,  Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");
		
		String user_Nick = CmmUtil.nvl((String)session.getAttribute("SS_USER_NICK"));
				
		
		log.info("세션user_Nick : "+ user_Nick);
				
		log.info(seq);
		BoardDTO bDTO = new BoardDTO();
		bDTO.setUser_Nick(user_Nick);

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);
		log.info("게시글 user_Nick : " +bDTO.getUser_Nick());
		
		return "project/boardDetail";
	}
	
	@RequestMapping(value = "project/MyboardDetail")
	public String MyBoardDetail(HttpSession session,HttpServletRequest request,  Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");
		
		String user_Nick = CmmUtil.nvl((String)session.getAttribute("SS_USER_NICK"));
				
		
		log.info("세션user_Nick : "+ user_Nick);
				
		log.info(seq);
		BoardDTO bDTO = new BoardDTO();
		bDTO.setUser_Nick(user_Nick);

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);
		log.info("게시글 user_Nick : " +bDTO.getUser_Nick());
		
		return "project/MyboardDetail";
	}
	
	@RequestMapping(value = "project/AdminboardDetail")
	public String AdminBoardDetail(HttpSession session,HttpServletRequest request,  Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");
		
		String user_Nick = CmmUtil.nvl((String)session.getAttribute("SS_USER_NICK"));
				
		
		log.info("세션user_Nick : "+ user_Nick);
				
		log.info(seq);
		BoardDTO bDTO = new BoardDTO();
		bDTO.setUser_Nick(user_Nick);

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);
		log.info("게시글 user_Nick : " +bDTO.getUser_Nick());
		
		return "project/AdminboardDetail";
	}

	//게시글 수정
	@RequestMapping(value = "project/boardModify")
	public String BoardModify(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);

		return "project/boardModify";
	}
	
	@RequestMapping(value = "project/MyboardModify")
	public String MyBoardModify(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);

		return "project/MyboardModify";
	}
	
	@RequestMapping(value = "project/AdminboardModify")
	public String AdminBoardModify(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();

		try {
			bDTO = BoardService.getBoardDetail(seq);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("bDTO", bDTO);

		return "project/AdminboardModify";
	}

	@RequestMapping(value = "project/boardModifyProc")
	public String BoardModifyProc(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String title = CmmUtil.nvl(request.getParameter("title"));
		String contents = request.getParameter("contents");
		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();
		bDTO.setContent(contents);
		bDTO.setSeq(seq);
		bDTO.setTitle(title);

		int result = 0;

		try {
			result = BoardService.updateBoard(bDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result > 0) {
			model.addAttribute("msg", "수정되었습니다.");
			model.addAttribute("url", "/project/boardDetail.do?seq=" + seq);

		} else {
			model.addAttribute("msg", "수정을 실패했습니다.");
			model.addAttribute("url", "/project/boardDetail.do?seq=" + seq);
		}

		return "redirect";

	}

	@RequestMapping(value = "project/boardDelete")
	public String boardDelete(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();
		bDTO.setSeq(seq);

		int result = 0;

		try {
			result = BoardService.boardDelete(bDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result > 0) {
			model.addAttribute("msg", "삭제되었습니다.");
			model.addAttribute("url", "/project/ProjectReview.do");

		} else {
			model.addAttribute("msg", "삭제 실패했습니다.");
			model.addAttribute("url", "/project/boardDetail.do?seq=" + seq);
		}

		return "redirect";

	}
	
	@RequestMapping(value = "project/MyboardDelete")
	public String MyboardDelete(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();
		bDTO.setSeq(seq);

		int result = 0;

		try {
			result = BoardService.boardDelete(bDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result > 0) {
			model.addAttribute("msg", "삭제되었습니다.");
			model.addAttribute("url", "/project/MyReview.do");

		} else {
			model.addAttribute("msg", "삭제 실패했습니다.");
			model.addAttribute("url", "/project/MyboardDetail.do?seq=" + seq);
		}

		return "redirect";

	}
	
	@RequestMapping(value = "project/AdminboardDelete")
	public String AdminboardDelete(HttpServletRequest request, Model model) {
		log.info(this.getClass().getName());

		String seq = request.getParameter("seq");

		BoardDTO bDTO = new BoardDTO();
		bDTO.setSeq(seq);

		int result = 0;

		try {
			result = BoardService.boardDelete(bDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result > 0) {
			model.addAttribute("msg", "삭제되었습니다.");
			model.addAttribute("url", "/project/ReviewAdmin.do");

		} else {
			model.addAttribute("msg", "삭제 실패했습니다.");
			model.addAttribute("url", "/project/ReviewAdmin.do");
		}

		return "redirect";

	}
	
	@RequestMapping(value = "/project/MyReview")
	public String MyReview(HttpSession session,HttpServletRequest request,  Model model) throws Exception {
		log.info(this.getClass().getName());
		
		String user_Nick = CmmUtil.nvl((String)session.getAttribute("SS_USER_NICK"));
		
		log.info("user_Nick : "+ user_Nick);
		
		
		UserDTO pDTO = new UserDTO();
		
		pDTO.setUser_Nick(user_Nick);
		
		log.info("@@@user_Nick : "+ user_Nick);
		
		List<BoardDTO> bList = null;

		log.info("--11--");

		try {
			bList = BoardService.getMyReview(pDTO);
			
			if (bList==null) {
				bList = new ArrayList<BoardDTO>();
			}
			
			log.info("bList size : "+ bList.size());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("bList", bList);
		

		log.info("--22--");
		log.info(bList);

		return "/project/MyReview";
		}
	
}