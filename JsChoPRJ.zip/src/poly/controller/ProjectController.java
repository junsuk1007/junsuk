package poly.controller;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;


import poly.dto.UserDTO;


import poly.service.IProjectService;
import poly.service.IUserService;
import poly.util.CmmUtil;


@Controller
public class ProjectController {

	private Logger log = Logger.getLogger(this.getClass());

	
	  @Resource(name = "ProjectService")
	  private IProjectService ProjectService;
	  
	  @Resource(name="UserService")
		private IUserService userservice;
  
	  
	/* 메인 화면 리퀘스트 매핑 */
	 

	@RequestMapping(value = "ProjectMain")
	public String ProjectMain1() {
		log.info(this.getClass());

		return "/project/ProjectMain";
	}

	@RequestMapping(value = "/project/ProjectMain")
	public String ProjectMain2() {
		log.info(this.getClass());

		return "/project/ProjectMain";
	}

	@RequestMapping(value = "/project/ProjectLogin")
	public String ProjectLogin() {
		log.info(this.getClass());

		return "/project/ProjectLogin";

	}

	@RequestMapping(value = "/project/ProjectSearch")
	public String ProjectSearch(HttpSession session,HttpServletRequest request,  Model model) {
		log.info(this.getClass());
		if(session.getAttribute("SS_USER_ID")==null) {
			model.addAttribute("url", "/project/ProjectLogin.do");
			model.addAttribute("msg", "로그인 후 이용 가능합니다.");
			
			return "redirect";
		}else {
						
			return "/project/ProjectSearch";
		}
		

	}

	@RequestMapping(value = "/project/ProjectFind")
	public String ProjectFind(HttpSession session,HttpServletRequest request,  Model model) throws Exception {
		log.info(this.getClass());

		if(session.getAttribute("SS_USER_ID")==null) {
			model.addAttribute("url", "/project/ProjectLogin.do");
			model.addAttribute("msg", "로그인 후 이용 가능합니다.");
			
			return "redirect";
		}else {
			
			return "/project/ProjectFind";
		}

	}
	@RequestMapping(value = "/project/ProjectMypage")
	public String ProjectMypage(HttpSession session,HttpServletRequest request, HttpServletResponse response,
			ModelMap model) {
		log.info(this.getClass());
		
		
		UserDTO pDTO = null;
				
		try {	
			String user_Id = CmmUtil.nvl((String)session.getAttribute("SS_USER_ID"));
			log.info("user_id : "+ user_Id);
			
			
			pDTO = new UserDTO();
			
			pDTO.setUser_Id(user_Id);
						
			pDTO = userservice.getUserInfo2(pDTO);
									
		}catch(Exception e) {
			e.printStackTrace();
		}
			
			model.addAttribute("pDTO", pDTO);
			log.info("user_Nick : "+ pDTO.getUser_Nick());
			log.info("user_Name : "+ pDTO.getUser_Name());
			
		
		return "/project/ProjectMypage";

	}

	
	/*
	 * @RequestMapping(value = "/project/ProjectReview.do") public String
	 * ProjectReview() { log.info(this.getClass());
	 * 
	 * return "/project/ProjectReview";
	 * 
	 * } boardController 로 옮김
	 */
	 

	
	
	/*
	 * @RequestMapping(value = "/project/ProjectJoin.do") public String
	 * ProjectJoin() { log.info(this.getClass());
	 * 
	 * return "/project/ProjectJoin";
	 * 
	 * }
	 */
	
	@RequestMapping(value="alert")
	public String alert() {
		return "/project/alert";
	}
	
	@RequestMapping(value="paging")
	public String paging() {
		return "paging";
	}
		
}
