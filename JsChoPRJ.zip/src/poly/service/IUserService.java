package poly.service;



import java.util.List;

import poly.dto.UserDTO;

public interface IUserService {

	int insertUserInfo(UserDTO pDTO) throws Exception;
	
	int getUserLoginCheck(UserDTO pDTO) throws Exception;

	int logOutTry(UserDTO pDTO) throws Exception;

	UserDTO getUserInfo(UserDTO pDTO) throws Exception;

	UserDTO getUserInfo2(UserDTO pDTO) throws Exception;

	UserDTO getUserPwFind(UserDTO pDTO) throws Exception;

	List<UserDTO> getUserInfo3() throws Exception;
	
	int getUserDelete(UserDTO rDTO) throws Exception;

	int getUserPwChange(UserDTO pDTO) throws Exception;

	 int UpdatePw(UserDTO pDTO) throws Exception;

	 String idcheck(String userid) throws Exception;

	String NickCheck(String user_Nick) throws Exception;

	int getUserIdFind(UserDTO pDTO) throws Exception;

	String getUserId(UserDTO pDTO) throws Exception;

}
