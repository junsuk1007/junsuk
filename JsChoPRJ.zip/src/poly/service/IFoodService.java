package poly.service;

public interface IFoodService {
	
	int getFoodInfo() throws Exception;

}
