package poly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import poly.dto.BoardDTO;
import poly.dto.UserDTO;
import poly.persistance.mapper.BoardMapper;
import poly.service.IBoardService;

@Service("BoardService")
public class BoardService implements IBoardService{
	
	@Resource(name="BoardMapper")
	private BoardMapper BoardMapper;
	
	@Override
	public int insertBoardInfo(BoardDTO bDTO) throws Exception{
		
		return BoardMapper.insertBoardInfo(bDTO);
	}
	
	@Override
	public List<BoardDTO> getProjectReview(int startNum, int endNum) throws Exception {
		
		return BoardMapper.getProjectReview(startNum, endNum);
	}

	@Override
	public String getBoardCnt() throws Exception{
		return BoardMapper.getBoardCnt();
	}
	
	@Override
	public BoardDTO getBoardDetail(String seq) throws Exception {
		
		return BoardMapper.getBoardDetail(seq);
	}
	
	@Override
	public UserDTO getBoardDetail2(UserDTO pDTO) throws Exception{
		
		return BoardMapper.getBoardDetail(pDTO);
	}

	@Override
	public int updateBoard(BoardDTO bDTO) throws Exception {
		
		return BoardMapper.updateBoard(bDTO);
	}
	
	@Override
	public int boardDelete(BoardDTO bDTO) throws Exception {
		
		return BoardMapper.boardDelete(bDTO);
	}
	
	@Override
	public List<BoardDTO> getMyReview(UserDTO pDTO) throws Exception {
		
		return BoardMapper.getMyReview(pDTO);
	}

	@Override
	public List<BoardDTO> getProjectReview2() throws Exception {
		// TODO Auto-generated method stub
		return BoardMapper.getProjectReview2();
	}

	

}
