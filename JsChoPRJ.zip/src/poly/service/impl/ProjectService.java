package poly.service.impl;

import org.springframework.stereotype.Service;

import poly.service.IProjectService;

@Service("ProjectService")
public class ProjectService implements IProjectService {

}
