package poly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;


import poly.dto.UserDTO;
import poly.persistance.mapper.UserMapper;
import poly.service.IUserService;
import poly.util.CmmUtil;

@Service("UserService")
public class UserService implements IUserService {

	@Resource(name = "UserMapper")
	private UserMapper userMapper;

	@Override
	public int insertUserInfo(UserDTO pDTO) throws Exception {
		// TODO Auto-generated method stub

		// 회원가입 성공: 1 아이디 중복 가입취소 : 2 기타 에러 : 0
		int res = 0;

		if (pDTO == null) {
			pDTO = new UserDTO();
		}

		UserDTO rDTO = userMapper.getUserExists(pDTO);

		if (rDTO == null) {
			rDTO = new UserDTO();
		}

		if (CmmUtil.nvl(rDTO.getExists_yn()).equals("Y")) {
			res = 2;
		} else {

			int success = userMapper.InsertUserInfo(pDTO);

			if (success > 0) {
				res = 1;
			} else {
				res = 0;
			}
		}

		return res;
	}

	@Override
	public int getUserLoginCheck(UserDTO pDTO) throws Exception {

		int res = 0;

		UserDTO rDTO = userMapper.getUserLoginCheck(pDTO);

		if (rDTO == null) {
			rDTO = new UserDTO();
		}

		if (CmmUtil.nvl(rDTO.getUser_Id()).length() > 0) {
			res = 1;
		}
		return res;
	}

	@Override
	public int logOutTry(UserDTO pDTO) throws Exception {

		int res = 0;

		UserDTO rDTO = userMapper.getUserLoginCheck(pDTO);

		if (rDTO == null) {
			rDTO = new UserDTO();
		}

		if (CmmUtil.nvl(rDTO.getUser_Id()).length() > 0) {
			res = 1;
		}
		return res;
	}

	@Override
	public UserDTO getUserInfo(UserDTO pDTO) throws Exception {
		
		return userMapper.getUserInfo(pDTO);
	}

	@Override
	public UserDTO getUserInfo2(UserDTO pDTO) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getUserInfo2(pDTO);
	}

	@Override
	public UserDTO getUserPwFind(UserDTO pDTO) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getUserPwFind(pDTO);
	}

	@Override
	public List<UserDTO> getUserInfo3() throws Exception {
		
		return userMapper.getUserInfo3();
	}

	@Override
	public int getUserDelete(UserDTO rDTO) throws Exception {
		
		return userMapper.getUserDelete(rDTO);
	}

	@Override
	public int getUserPwChange(UserDTO pDTO) throws Exception {
		int res = 0;

		UserDTO rDTO = userMapper.getUserPwChange(pDTO);

		if (rDTO == null) {
			rDTO = new UserDTO();
		}

		if (CmmUtil.nvl(rDTO.getUser_Id()).length() > 0) {
			res = 1;
		}
		return res;
	}

	@Override
	public int UpdatePw(UserDTO pDTO) throws Exception {
		
		
				int res = 0;

				if (pDTO == null) {
					pDTO = new UserDTO();
				}
				
					int success = userMapper.UpdatePw(pDTO);

					if (success > 0) {
						res = 1;
					} else {
						res = 0;
				}
				
				return res;
			}

	@Override
	public String idcheck(String userid) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.idcheck(userid);
	}

	@Override
	public String NickCheck(String user_Nick) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.NickCheck(user_Nick);
	}

	@Override
	public int getUserIdFind(UserDTO pDTO) throws Exception {
		int res = 0;

		UserDTO rDTO = userMapper.getUserIdFInd(pDTO);

		if (rDTO == null) {
			rDTO = new UserDTO();
		}

		if (CmmUtil.nvl(rDTO.getUser_Name()).length() > 0) {
			res = 1;
		}
		return res;
	}

	@Override
	public String getUserId(UserDTO pDTO) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getUserId(pDTO);
	}
	

	
}
