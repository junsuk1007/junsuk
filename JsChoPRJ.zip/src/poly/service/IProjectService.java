package poly.service;

public interface IProjectService {

}
