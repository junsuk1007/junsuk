package poly.service;

import java.util.List;

import poly.dto.BoardDTO;
import poly.dto.UserDTO;

public interface IBoardService {

	int insertBoardInfo(BoardDTO bDTO) throws Exception;

	List<BoardDTO> getProjectReview(int startNum, int endNum) throws Exception;
	
	String getBoardCnt() throws Exception;

	BoardDTO getBoardDetail(String seq) throws Exception;

	int updateBoard(BoardDTO bDTO) throws Exception;

	int boardDelete(BoardDTO bDTO) throws Exception;

	List<BoardDTO> getMyReview(UserDTO pDTO) throws Exception;

	UserDTO getBoardDetail2(UserDTO pDTO) throws Exception;

	List<BoardDTO> getProjectReview2() throws Exception;
	
	
}
