package poly.dto;

public class MovieDTO {

	private String rank_chkeck_time;
	private String seq;
	private String movie_rank;
	private String movie_nm;
	private String movie_reserve;
	private String score;
	private String open_day;
	private String reg_id;
	private String reg_dt;
	private String chg_id;
	private String chg_dt;
	
	
	public String getRank_chkeck_time() {
		return rank_chkeck_time;
	}
	public void setRank_chkeck_time(String rank_chkeck_time) {
		this.rank_chkeck_time = rank_chkeck_time;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getMovie_rank() {
		return movie_rank;
	}
	public void setMovie_rank(String movie_rank) {
		this.movie_rank = movie_rank;
	}
	public String getMovie_nm() {
		return movie_nm;
	}
	public void setMovie_nm(String movie_nm) {
		this.movie_nm = movie_nm;
	}
	public String getMovie_reserve() {
		return movie_reserve;
	}
	public void setMovie_reserve(String movie_reserve) {
		this.movie_reserve = movie_reserve;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getOpen_day() {
		return open_day;
	}
	public void setOpen_day(String open_day) {
		this.open_day = open_day;
	}
	public String getReg_id() {
		return reg_id;
	}
	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getChg_id() {
		return chg_id;
	}
	public void setChg_id(String chg_id) {
		this.chg_id = chg_id;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	
	
}
