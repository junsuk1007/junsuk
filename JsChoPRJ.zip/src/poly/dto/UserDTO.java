package poly.dto;

public class UserDTO {
	
	private String user_Id;
	private String user_Pw;
	private String user_Name;
	private String user_Nick;
	private String user_Seq;
	private String reg_dt;
	
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	private String exists_yn;
	
	public String getExists_yn() {
		return exists_yn;
	}
	public void setExists_yn(String exists_yn) {
		this.exists_yn = exists_yn;
	}
	public String getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	public String getUser_Pw() {
		return user_Pw;
	}
	public void setUser_Pw(String user_Pw) {
		this.user_Pw = user_Pw;
	}
	public String getUser_Name() {
		return user_Name;
	}
	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}
	public String getUser_Nick() {
		return user_Nick;
	}
	public void setUser_Nick(String user_Nick) {
		this.user_Nick = user_Nick;
	}
	public String getUser_Seq() {
		return user_Seq;
	}
	public void setUser_Seq(String user_Seq) {
		this.user_Seq = user_Seq;
	}
}
