package poly.dto;

public class BoardDTO {
	private String title;
	private String content;
	private String regDate;
	private String seq;
	private String user_Nick;
	private String chgDate;
	private int iNum;
	
	
	
	public int getiNum() {
		return iNum;
	}
	public void setiNum(int iNum) {
		this.iNum = iNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getUser_Nick() {
		return user_Nick;
	}
	public void setUser_Nick(String user_Nick) {
		this.user_Nick = user_Nick;
	}
	public String getChgDate() {
		return chgDate;
	}
	public void setChgDate(String chgDate) {
		this.chgDate = chgDate;
	}
	
	

}
