package poly.persistance.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import config.Mapper;
import poly.dto.BoardDTO;
import poly.dto.UserDTO;

@Mapper("BoardMapper")
public interface BoardMapper {



	int insertBoardInfo(BoardDTO bDTO)throws Exception;

	//게시판 리스트
	List<BoardDTO> getProjectReview(@Param("startNum")int startNum, @Param("endNum")int endNum) throws Exception;

	//게시판 페이징
	String getBoardCnt() throws Exception;
	
	int updateBoard(BoardDTO bDTO) throws Exception;

	BoardDTO getBoardDetail(String seq) throws Exception;
	
	UserDTO getBoardDetail(UserDTO pDTO) throws Exception;

	int boardDelete(BoardDTO bDTO) throws Exception;

	List<BoardDTO> getMyReview(UserDTO pDTO) throws Exception;

	List<BoardDTO> getProjectReview2() throws Exception;

	

}
