package poly.persistance.mapper;

import java.util.List;

import config.Mapper;
import poly.dto.UserDTO;


@Mapper("UserMapper")
public interface UserMapper {

		
	//회원가입하기
	int InsertUserInfo(UserDTO pDTO) throws Exception;
	
	//회원가입전 중복체크하기
	UserDTO getUserExists(UserDTO pDTO) throws Exception;

	UserDTO getUserLoginCheck(UserDTO pDTO) throws Exception;

	UserDTO getUserInfo(UserDTO pDTO)throws Exception;

	UserDTO getUserInfo2(UserDTO pDTO) throws Exception;

	UserDTO getUserPwFind(UserDTO pDTO) throws Exception;
	
	List<UserDTO> getUserInfo3() throws Exception;

	int getUserDelete(UserDTO rDTO) throws Exception;

	UserDTO getUserPwChange(UserDTO pDTO) throws Exception;

	int UpdatePw(UserDTO pDTO) throws Exception;

	String idcheck(String userid) throws Exception;

	String NickCheck(String user_Nick) throws Exception;

	UserDTO getUserIdFInd(UserDTO pDTO) throws Exception;

	String getUserId(UserDTO pDTO) throws Exception;

}
